function contrast() {
        var element = document.body;
        element.classList.toggle("mystyle");
    }

    function darkheader() {
        var element = document.getElementById("header1");
        element.classList.toggle("darkheader");
    }

    function darkheader2() {
        var element = document.getElementById("header2");
        element.classList.toggle("darkheader2");
    }

    function dark() {
        var element = document.body;
        element.classList.toggle("dark");
    }

    function darkfooter() {
        var element = document.getElementById("footer");
        element.classList.toggle("darkfooter");
    }

   





    function lichtheader() {
        var element = document.getElementById("header1");
        element.classList.toggle("lichtheader");
    }

    function lichtheader2() {
        var element = document.getElementById("header2");
        element.classList.toggle("lichtheader2");
    }

    function licht() {
        var element = document.body;
        element.classList.toggle("licht");
    }

    function lichtfooter() {
        var element = document.getElementById("footer");
        element.classList.toggle("lichtfooter");
    }