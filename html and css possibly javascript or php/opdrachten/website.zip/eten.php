<?php include "header.php" ?>
<link rel="javaschript" href="toegang.js">

<body>
    <main>
        <div class="eten-container">
            <h1 class="jua">Menu</h1>
            <h2>Dit is ons menu.</h2>

            <div class="columns-container">

                <div class="column-left">
                <h2>## Voorgerechten</p>
                <p class="gerecht">** Miso Soep ** 4,50</p>
                <p class="uitleg">Traditionele japanse soep met tofu zeewier en lente-ui</p>
                <p class="gerecht">** Edamame ** 5,00</p>
                <p class="uitleg">Gestoomde sojabonen met zeezout</p>
                <p class="gerecht">** Wakame Salade ** 6,50</p>
                <p class="uitleg">Zeewier salade met sesam dressing</p>
                <p class="gerecht">## Nigiri Sushi (2 stuks)</p>
                <p class="uitleg">** Sake(zalm) ** 4,50</p>
                <p class="uitleg">** Maguro(tonijn) ** 5,00</p>
                <p class="uitleg">** Ebi(garnaal) ** 4,50</p>
                <p class="uitleg">** Unagi(paling) ** 5,50</p>
                <p class="uitleg">** Tamago(ei) ** 4,00</p>
                <p class="gerecht">** California Roll (6 stuks) ** 8,50</p>
                <p class="uitleg">Krabstick, avocado, komkommer en masago</p>
                <p class="gerecht">** Spicy Tuna Roll ** 9,00 (6 stuks) ** 8,50</p>
                <p class="uitleg">Tonijn, spicy mayonaise en lente-ui</p>
                </div>
                <div class="column-right">
                ** Salmon Avocado Roll ** 9,00
Verse zalm en avocado

** Cucumber Roll ** 6,50
komkommer en sesam(vegan)

## special rolls (8 stuks)
** Dragon Roll ** 15,50
Tempura garnaal, avocado, komkommer, unagi
en unagi saus

** Rainbow Roll ** 16,50
California roll bedekt met diverse soorten vis

** Grispy Chicken Roll ** 16,50
Krokante kip, avocado, komkommer, teriyaki
saus

** Tempura Roll ** 15,50
Gefrituurde garnaal, avocado, komkommer,
spicy mayonaise
                </div>

        </div>
    </main>
   
</body>